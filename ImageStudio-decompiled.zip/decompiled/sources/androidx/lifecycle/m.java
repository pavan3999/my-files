package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface m<T> {
    void a(T t);
}
