package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(androidx.versionedparcelable.a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.a = (IconCompat) aVar.v(remoteActionCompat.a, 1);
        remoteActionCompat.b = aVar.l(remoteActionCompat.b, 2);
        remoteActionCompat.c = aVar.l(remoteActionCompat.c, 3);
        remoteActionCompat.f248d = (PendingIntent) aVar.r(remoteActionCompat.f248d, 4);
        remoteActionCompat.f249e = aVar.h(remoteActionCompat.f249e, 5);
        remoteActionCompat.f250f = aVar.h(remoteActionCompat.f250f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, androidx.versionedparcelable.a aVar) {
        aVar.x(false, false);
        aVar.M(remoteActionCompat.a, 1);
        aVar.D(remoteActionCompat.b, 2);
        aVar.D(remoteActionCompat.c, 3);
        aVar.H(remoteActionCompat.f248d, 4);
        aVar.z(remoteActionCompat.f249e, 5);
        aVar.z(remoteActionCompat.f250f, 6);
    }
}
