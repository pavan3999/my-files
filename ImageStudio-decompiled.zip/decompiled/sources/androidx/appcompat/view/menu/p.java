package androidx.appcompat.view.menu;

import android.widget.ListView;

/* JADX INFO: loaded from: classes.dex */
public interface p {
    boolean a();

    void b();

    void dismiss();

    ListView g();
}
