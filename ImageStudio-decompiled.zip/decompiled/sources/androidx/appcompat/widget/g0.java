package androidx.appcompat.widget;

import android.graphics.Rect;

/* JADX INFO: loaded from: classes.dex */
public interface g0 {

    public interface a {
        void a(Rect rect);
    }

    void setOnFitSystemWindowsListener(a aVar);
}
