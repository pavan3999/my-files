package d.l;

import android.R;

/* JADX INFO: loaded from: classes.dex */
public final class c {
    public static final int ColorStateListItem_alpha = 2;
    public static final int ColorStateListItem_android_alpha = 1;
    public static final int ColorStateListItem_android_color = 0;
    public static final int FontFamilyFont_android_font = 0;
    public static final int FontFamilyFont_android_fontStyle = 2;
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    public static final int FontFamilyFont_android_fontWeight = 1;
    public static final int FontFamilyFont_android_ttcIndex = 3;
    public static final int FontFamilyFont_font = 5;
    public static final int FontFamilyFont_fontStyle = 6;
    public static final int FontFamilyFont_fontVariationSettings = 7;
    public static final int FontFamilyFont_fontWeight = 8;
    public static final int FontFamilyFont_ttcIndex = 9;
    public static final int FontFamily_fontProviderAuthority = 0;
    public static final int FontFamily_fontProviderCerts = 1;
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    public static final int FontFamily_fontProviderPackage = 4;
    public static final int FontFamily_fontProviderQuery = 5;
    public static final int GradientColorItem_android_color = 0;
    public static final int GradientColorItem_android_offset = 1;
    public static final int GradientColor_android_centerColor = 7;
    public static final int GradientColor_android_centerX = 3;
    public static final int GradientColor_android_centerY = 4;
    public static final int GradientColor_android_endColor = 1;
    public static final int GradientColor_android_endX = 10;
    public static final int GradientColor_android_endY = 11;
    public static final int GradientColor_android_gradientRadius = 5;
    public static final int GradientColor_android_startColor = 0;
    public static final int GradientColor_android_startX = 8;
    public static final int GradientColor_android_startY = 9;
    public static final int GradientColor_android_tileMode = 6;
    public static final int GradientColor_android_type = 2;
    public static final int RecyclerView_android_clipToPadding = 1;
    public static final int RecyclerView_android_descendantFocusability = 2;
    public static final int RecyclerView_android_orientation = 0;
    public static final int RecyclerView_fastScrollEnabled = 3;
    public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 4;
    public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 5;
    public static final int RecyclerView_fastScrollVerticalThumbDrawable = 6;
    public static final int RecyclerView_fastScrollVerticalTrackDrawable = 7;
    public static final int RecyclerView_layoutManager = 8;
    public static final int RecyclerView_reverseLayout = 9;
    public static final int RecyclerView_spanCount = 10;
    public static final int RecyclerView_stackFromEnd = 11;
    public static final int[] ColorStateListItem = {R.attr.color, R.attr.alpha, com.redlee90.imagekitchenforandroid.R.attr.alpha};
    public static final int[] FontFamily = {com.redlee90.imagekitchenforandroid.R.attr.fontProviderAuthority, com.redlee90.imagekitchenforandroid.R.attr.fontProviderCerts, com.redlee90.imagekitchenforandroid.R.attr.fontProviderFetchStrategy, com.redlee90.imagekitchenforandroid.R.attr.fontProviderFetchTimeout, com.redlee90.imagekitchenforandroid.R.attr.fontProviderPackage, com.redlee90.imagekitchenforandroid.R.attr.fontProviderQuery};
    public static final int[] FontFamilyFont = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, com.redlee90.imagekitchenforandroid.R.attr.font, com.redlee90.imagekitchenforandroid.R.attr.fontStyle, com.redlee90.imagekitchenforandroid.R.attr.fontVariationSettings, com.redlee90.imagekitchenforandroid.R.attr.fontWeight, com.redlee90.imagekitchenforandroid.R.attr.ttcIndex};
    public static final int[] GradientColor = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};
    public static final int[] GradientColorItem = {R.attr.color, R.attr.offset};
    public static final int[] RecyclerView = {R.attr.orientation, R.attr.clipToPadding, R.attr.descendantFocusability, com.redlee90.imagekitchenforandroid.R.attr.fastScrollEnabled, com.redlee90.imagekitchenforandroid.R.attr.fastScrollHorizontalThumbDrawable, com.redlee90.imagekitchenforandroid.R.attr.fastScrollHorizontalTrackDrawable, com.redlee90.imagekitchenforandroid.R.attr.fastScrollVerticalThumbDrawable, com.redlee90.imagekitchenforandroid.R.attr.fastScrollVerticalTrackDrawable, com.redlee90.imagekitchenforandroid.R.attr.layoutManager, com.redlee90.imagekitchenforandroid.R.attr.reverseLayout, com.redlee90.imagekitchenforandroid.R.attr.spanCount, com.redlee90.imagekitchenforandroid.R.attr.stackFromEnd};
}
