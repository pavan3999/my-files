package d.f;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    public static final int alpha = 2130903084;
    public static final int font = 2130903360;
    public static final int fontProviderAuthority = 2130903362;
    public static final int fontProviderCerts = 2130903363;
    public static final int fontProviderFetchStrategy = 2130903364;
    public static final int fontProviderFetchTimeout = 2130903365;
    public static final int fontProviderPackage = 2130903366;
    public static final int fontProviderQuery = 2130903367;
    public static final int fontStyle = 2130903368;
    public static final int fontVariationSettings = 2130903369;
    public static final int fontWeight = 2130903370;
    public static final int ttcIndex = 2130903748;
}
