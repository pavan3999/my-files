package com.google.android.material.textfield;

/* JADX INFO: loaded from: classes.dex */
class b extends e {
    b(TextInputLayout textInputLayout) {
        super(textInputLayout);
    }

    @Override // com.google.android.material.textfield.e
    void a() {
        this.a.setEndIconOnClickListener(null);
        this.a.setEndIconOnLongClickListener(null);
    }
}
